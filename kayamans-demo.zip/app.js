/* Kayaman's Farm — chatbot venditore. Made in Italy.
   Motore intelligente a regole (neuromarketing) + hook opzionale Claude API.
   Funziona offline aprendo index.html. */
(function () {
  "use strict";
  const D = window.KF_DATA, CFG = window.KF_CONFIG;
  const $ = (s, r = document) => r.querySelector(s);
  const $$ = (s, r = document) => [...r.querySelectorAll(s)];
  const money = n => n.toFixed(2).replace(".", ",") + " €";
  // anchoring: mostra prezzo precedente sbarrato + risparmio sulle offerte
  function priceHTML(p) {
    if (p.compareAt && p.compareAt > p.price) {
      const save = t("save", LANG).replace("{v}", money(p.compareAt - p.price));
      return `<span class="price-was">${money(p.compareAt)}</span><span class="card-price-now">${money(p.price)}</span><span class="price-save">${save}</span>`;
    }
    return `<span class="card-price-now">${money(p.price)}</span>`;
  }
  const t = (key, lang) => (D.ui[key] && D.ui[key][lang]) || (D.ui[key] && D.ui[key].es) || key;
  // rating stabile per prodotto (deterministico dall'id) — prova sociale
  function prodRating(p) {
    const stars = Math.round((4.2 + ((p.id * 7) % 9) / 10) * 10) / 10; // 4.2..5.0
    const count = 24 + (p.id * 53) % 420;
    const sold = 3 + (p.id * 17) % 28;
    return { stars, count, sold };
  }
  function starsHTML(stars) {
    const full = Math.round(stars);
    let s = "";
    for (let i = 0; i < 5; i++) s += `<span class="${i < full ? "on" : ""}">★</span>`;
    return `<span class="stars">${s}</span>`;
  }

  let LANG = "es";
  const state = {
    cart: [],                 // {id, qty}
    profile: {},              // experience, motive, category, budget
    step: 0,                  // profiling step
    flow: "idle",            // idle | profiling | recommend | free
    chatOpen: false,
    minimized: false,
    badge: 0,
    engaged: false,          // l'utente ha interagito almeno una volta in chat
    discount: 0              // sconto pack applicato al carrello
  };

  /* =========================================================
     1. LINGUA
     ========================================================= */
  function detectLang() {
    const b = (navigator.language || "es").slice(0, 2);
    return ["es", "en", "it"].includes(b) ? b : "es";
  }
  let built = false;
  function setLang(lang) {
    LANG = lang;
    document.documentElement.lang = lang;
    $$(".lang-switch button, .age-lang button").forEach(b =>
      b.classList.toggle("active", b.dataset.lang === lang));
    paintStaticText();
    renderNav();
    renderCatTiles();
    renderReviews();
    if (!built) {
      // prima volta: costruisci griglie (con immagini)
      renderRows();
      renderShop();
      built = true;
    } else {
      // cambio lingua: aggiorna solo i TESTI, niente ricostruzione (no flash delle foto)
      renderFilters();
      relabelCards();
    }
    renderCart();
    // se la chat è aperta, ri-renderizza le quick-reply attive nella nuova lingua
    if (state.chatOpen) {
      if (state.flow === "profiling") { const q = D.profiling[state.step]; if (q) renderProfilingQuick(q); }
      else if (state.flow === "free") offerFreeQuick();
    }
  }
  function paintStaticText() {
    $("#ageTitle").textContent = t("ageGateTitle", LANG);
    $("#ageMsg").textContent = t("ageGateMsg", LANG);
    $("#ageYes").textContent = t("ageYes", LANG);
    $("#ageNo").textContent = t("ageNo", LANG);
    $("#ageDenied").textContent = t("ageDenied", LANG);
    $("#shopLead").textContent = t("shopLead", LANG);
    const trust = (D.ui.trust && (D.ui.trust[LANG] || D.ui.trust.es)) || [];
    $("#heroTrust").innerHTML = trust.map(x => `<span>${x}</span>`).join("");
    // --- nuovo layout stile sito reale ---
    const S = D.site, sv = k => (S[k] && (S[k][LANG] || S[k].es)) || S[k];
    const set = (id, v) => { const el = $(id); if (el != null && v != null) el.textContent = v; };
    set("#tbShip", sv("topShipping")); set("#tbHours", sv("topHours")); set("#tbPhone", S.topPhone);
    set("#tbLogin", sv("login")); set("#tbRegister", sv("register"));
    set("#brandScript", { es: "Tienda Online", en: "Online Store", it: "Negozio Online" }[LANG]);
    set("#heroEyebrow", sv("bannerKicker")); set("#heroScript", sv("bannerScript"));
    set("#heroSub", sv("bannerSub"));
    const hc = $("#heroCta"); if (hc) hc.textContent = sv("bannerCta");
    const hc2 = $("#heroCta2"); if (hc2) hc2.textContent = sv("bannerCta2");
    set("#catShopTitle", sv("catShop"));
    set("#secDestacados", sv("secDestacados")); set("#secNovedades", sv("secNovedades")); set("#secOfertas", sv("secOfertas"));
    set("#shopTitle", sv("allShop"));
    set("#footTienda", sv("footTienda")); set("#footLinks", sv("footLinks")); set("#footPay", sv("footPay"));
    set("#footAddr", S.footAddr); set("#footEmail", S.footEmail); set("#footHours", sv("footHours"));
    const fl = $("#footLinksList"); if (fl) { const list = (S.footLinksList[LANG] || S.footLinksList.es); fl.innerHTML = list.map(x => `<li>${x}</li>`).join(""); }
    const si = $("#searchInput"); if (si) si.placeholder = sv("searchPh");
    // --- marketing: fiducia, rating, recensioni ---
    const M = D.marketing;
    const trustEl = $("#trustStrip");
    if (trustEl) trustEl.innerHTML = (M.trust[LANG] || M.trust.es).map(x => `<span>${x}</span>`).join("");
    const hr = $("#heroRating");
    if (hr) hr.innerHTML = `${starsHTML(parseFloat(M.globalRating.value))}<b>${M.globalRating.value}</b><span class="hr-count">· ${M.globalRating.count} ${({ es: "reseñas", en: "reviews", it: "recensioni" })[LANG]}</span>`;
    set("#reviewsTitle", M.reviewsTitle[LANG] || M.reviewsTitle.es);
    set("#reviewsSub", M.reviewsSub[LANG] || M.reviewsSub.es);
    const NL = M.newsletter;
    set("#nlTitle", NL.title[LANG] || NL.title.es);
    set("#nlSub", NL.sub[LANG] || NL.sub.es);
    const nle = $("#nlEmail"); if (nle) nle.placeholder = NL.placeholder[LANG] || NL.placeholder.es;
    set("#nlCta", NL.cta[LANG] || NL.cta.es);
    set("#mbCta", t("checkout", LANG));
    $("#cartLabel").textContent = t("cart", LANG);
    $("#cartTitle").textContent = t("cart", LANG);
    $("#totalLabel").textContent = t("total", LANG);
    $("#checkoutBtn").textContent = t("checkout", LANG);
    $("#chatTitle").textContent = t("chatTitle", LANG);
    $("#chatOnline").textContent = t("online", LANG);
    $("#chatInput").placeholder = t("chatPlaceholder", LANG);
    $("#exitTitle").textContent = D.reengage.exitIntent.title[LANG];
    $("#exitBody").textContent = D.reengage.exitIntent.body[LANG];
    $("#exitCta").textContent = D.reengage.exitIntent.cta[LANG];
    $("#exitExpires").textContent = D.reengage.exitIntent.expires[LANG];
    const pt = $("#promoText"); if (pt) pt.textContent = t("promoText", LANG);
    const po = $("#promoOffer"); if (po) po.textContent = t("promoOffer", LANG);
    const pe = $("#promoEndsLabel"); if (pe) pe.textContent = t("promoEnds", LANG);
  }

  /* =========================================================
     2. AGE GATE 18+
     ========================================================= */
  function initAgeGate() {
    $$(".age-lang button").forEach(b => b.onclick = () => setLang(b.dataset.lang));
    $("#ageYes").onclick = () => {
      try { localStorage.setItem("kf_age", "1"); } catch (e) {}
      enterSite();
    };
    $("#ageNo").onclick = () => {
      $(".age-actions").style.display = "none";
      $("#ageDenied").hidden = false;
    };
    let ok = false;
    try { ok = localStorage.getItem("kf_age") === "1"; } catch (e) {}
    if (ok) enterSite();
  }
  function enterSite() {
    $("#ageGate").style.display = "none";
    $("#site").hidden = false;
    $("#chatLauncher").hidden = false;
    startReengage();
    startSocialProof();
    startPromoCountdown();
    checkLazy(); // carica le foto già visibili ora che il sito è mostrato
    // l'elfo compagno entra in scena e si presenta
    setTimeout(() => { if (!state.chatOpen) companionSay(comp("welcome"), 7000); }, 2500);
  }
  // barra promo: countdown di urgenza (si ferma a 00:00)
  let promoInt = null;
  function startPromoCountdown() {
    let secs = 15 * 60;
    const cd = $("#promoCd");
    if (!cd) return;
    const tick = () => {
      const m = String(Math.floor(secs / 60)).padStart(2, "0");
      const s = String(secs % 60).padStart(2, "0");
      cd.textContent = `${m}:${s}`;
      if (secs <= 0) { clearInterval(promoInt); return; }
      secs--;
    };
    tick();
    promoInt = setInterval(tick, 1000);
  }

  /* =========================================================
     3. NAV + SHOP
     ========================================================= */
  let activeCat = "all";
  let searchQuery = "";
  function doSearch(q) { searchQuery = (q || "").toLowerCase(); activeCat = "all"; renderShop(); scrollToShop(); }
  function categories() {
    return [...new Set(D.products.map(p => p.category))];
  }
  function catLabel(cat) { const m = D.catLabels && D.catLabels[cat]; return m ? (m[LANG] || m.es) : cat; }
  function closeNavbar() { const nb = document.querySelector(".navbar"); if (nb) nb.classList.remove("open"); }
  function renderNav() {
    const nav = $("#nav");
    nav.innerHTML = "";
    categories().forEach(cat => {
      const b = document.createElement("button");
      b.textContent = catLabel(cat);
      b.dataset.cat = cat;
      b.onclick = () => { searchQuery = ""; activeCat = cat; syncFilters(); renderShop(); closeNavbar(); scrollToShop(); };
      nav.appendChild(b);
    });
  }
  function renderCatTiles() {
    const wrap = $("#catTiles");
    if (!wrap) return;
    wrap.innerHTML = "";
    categories().forEach(cat => {
      const count = D.products.filter(p => p.category === cat).length;
      const el = document.createElement("div");
      el.className = "cat-tile";
      el.innerHTML = `<div class="ct-emoji">${emoji[cat] || "🌿"}</div><div class="ct-name">${catLabel(cat)}</div><div class="ct-count">${count}</div>`;
      el.onclick = () => { searchQuery = ""; activeCat = cat; syncFilters(); renderShop(); scrollToShop(); };
      wrap.appendChild(el);
    });
  }
  // righe prodotti stile sito reale (Destacados / Novedades / Ofertas)
  function renderRows() {
    const rows = {
      rowDestacados: D.products.filter(p => p.badge === "Bestseller"),
      rowNovedades: D.products.filter(p => p.badge === "Nuevo"),
      rowOfertas: D.products.filter(p => p.badge === "Oferta")
    };
    Object.entries(rows).forEach(([id, list]) => {
      const el = $("#" + id);
      if (!el) return;
      const pool = list.length ? list : D.products.slice(0, 4);
      el.innerHTML = pool.map(cardHTML).join("");
      wireAddButtons(el);
      lazyImages(el);
    });
  }
  function renderReviews() {
    const g = $("#reviewsGrid");
    if (!g) return;
    const M = D.marketing;
    g.innerHTML = M.testimonials.map(r => `<div class="review-card">
      ${starsHTML(r.stars)}
      <div class="rv-text">“${r[LANG] || r.es}”</div>
      <div class="rv-foot"><div class="rv-av">${r.name[0]}</div>
        <div><div class="rv-name">${r.name}</div><div class="rv-ver">✓ ${M.verified[LANG] || M.verified.es}</div></div>
      </div></div>`).join("");
  }
  // cambio lingua fluido: aggiorna solo i testi dei pulsanti nelle card già costruite
  function relabelCards() {
    $$("#grid [data-add],#rowDestacados [data-add],#rowNovedades [data-add],#rowOfertas [data-add]").forEach(b => {
      if (b.textContent.indexOf("✓") === -1) b.textContent = t("addToCart", LANG);
    });
  }
  function wireAddButtons(scope) {
    $$("[data-add]", scope).forEach(b => b.onclick = () => {
      addToCart(+b.dataset.add);
      b.textContent = t("added", LANG);
      setTimeout(() => b.textContent = t("addToCart", LANG), 1200);
    });
  }
  function renderFilters() {
    const f = $("#filters");
    f.innerHTML = "";
    const cats = ["all", ...categories()];
    cats.forEach(cat => {
      const b = document.createElement("button");
      b.textContent = cat === "all" ? t("all", LANG) : catLabel(cat);
      b.dataset.cat = cat;
      b.classList.toggle("active", cat === activeCat && !searchQuery);
      b.onclick = () => { searchQuery = ""; activeCat = cat; syncFilters(); renderShop(); };
      f.appendChild(b);
    });
  }
  function syncFilters() {
    $$("#filters button").forEach(b => b.classList.toggle("active", b.dataset.cat === activeCat && !searchQuery));
    $$("#nav button").forEach(b => b.classList.toggle("active", b.dataset.cat === activeCat && !searchQuery));
  }
  const emoji = { Cartine: "🧻", Grinder: "⚙️", Accendini: "🔥", Vaporizzatori: "💨", CBD: "🌿", Edibles: "🍭", Accessori: "🎁", Bong: "🫧" };
  // lazy-load foto prodotto: carica solo quelle vicine alla viewport (su scroll/resize)
  function checkLazy() {
    const vh = window.innerHeight || document.documentElement.clientHeight;
    $$(".card-img[data-bg]").forEach(e => {
      const r = e.getBoundingClientRect();
      if (r.bottom > -300 && r.top < vh + 300) {
        e.style.backgroundImage = `url('${e.dataset.bg}')`;
        e.removeAttribute("data-bg");
      }
    });
  }
  function lazyImages() { checkLazy(); }
  let lazyThrottle = null;
  function onScrollLazy() {
    if (lazyThrottle) return;
    lazyThrottle = setTimeout(() => { lazyThrottle = null; checkLazy(); }, 120);
  }
  function cardHTML(p) {
    const img = p.imageUrl ? `data-bg="${p.imageUrl}"` : "";
    const ph = p.imageUrl ? "" : (emoji[p.category] || "🌿");
    const badge = p.badge ? `<span class="card-badge badge-${p.badge}">${p.badge}</span>` : "";
    const low = p.stock <= 6 ? `<span class="card-stock">${t("onlyLeft", LANG).replace("{n}", p.stock)}</span>` : "";
    const rt = prodRating(p);
    const rating = `<div class="card-rating">${starsHTML(rt.stars)}<b>${rt.stars.toFixed(1)}</b><span class="rev">(${rt.count})</span></div>`;
    const urgency = (p.badge === "Bestseller" || p.badge === "Oferta")
      ? `<div class="card-urgency">🔥 ${rt.sold} ${D.marketing.soldToday[LANG] || D.marketing.soldToday.es}</div>` : "";
    return `<div class="card">
      <div class="card-img" ${img}>${ph}${badge}${low}</div>
      <div class="card-body">
        <span class="card-cat">${catLabel(p.category)}</span>
        <div class="card-name">${p.name}</div>
        ${rating}
        <div class="card-desc">${p.description}</div>
        ${urgency}
        <div class="card-foot">
          <span class="card-price">${priceHTML(p)}</span>
          <button class="btn btn-primary" data-add="${p.id}">${t("addToCart", LANG)}</button>
        </div>
      </div>
    </div>`;
  }
  function renderShop() {
    renderFilters();
    const grid = $("#grid");
    let list = activeCat === "all" ? D.products.slice() : D.products.filter(p => p.category === activeCat);
    if (searchQuery) list = D.products.filter(p => (p.name + " " + catLabel(p.category) + " " + p.description).toLowerCase().includes(searchQuery));
    grid.innerHTML = list.length ? list.map(cardHTML).join("")
      : `<p style="color:var(--muted);grid-column:1/-1">${({ es: "Sin resultados. Pregúntale a Kaya 👇", en: "No results. Ask Kaya 👇", it: "Nessun risultato. Chiedi a Kaya 👇" })[LANG]}</p>`;
    wireAddButtons(grid);
    lazyImages(grid);
  }
  function scrollToShop() { const m = $("#shopMain") || $(".shop"); if (m) m.scrollIntoView({ behavior: "smooth" }); }

  /* =========================================================
     4. CARRELLO
     ========================================================= */
  function addToCart(id, qty = 1, opts = {}) {
    const row = state.cart.find(r => r.id === id);
    if (row) row.qty += qty; else state.cart.push({ id, qty });
    renderCart();
    if (!opts.silent) { toast(t("added", LANG)); pingSound(); cartBump(); if (state.chatOpen) sellerReact(); onAdded(prod(id)); }
  }
  function cartBump() {
    const c = $("#cartCount");
    c.style.transition = "transform 220ms cubic-bezier(.34,1.56,.64,1)";
    c.style.transform = "scale(1.4)";
    setTimeout(() => c.style.transform = "scale(1)", 220);
  }
  function cartCount() { return state.cart.reduce((s, r) => s + r.qty, 0); }
  function cartSubtotal() { return state.cart.reduce((s, r) => s + r.qty * prod(r.id).price, 0); }
  function cartTotal() { return Math.max(0, cartSubtotal() - state.discount); }
  function prod(id) { return D.products.find(p => p.id === id); }
  function renderCart() {
    $("#cartCount").textContent = cartCount();
    if (!state.cart.length) state.discount = 0;
    const body = $("#cartItems");
    if (!state.cart.length) {
      body.innerHTML = `<div class="cart-empty">${t("emptyCart", LANG)}</div>`;
    } else {
      const discRow = state.discount > 0
        ? `<div class="cart-row cart-disc"><div class="cr-info"><div class="cr-name">🎁 ${({ es: "Descuento pack", en: "Pack discount", it: "Sconto pack" })[LANG]}</div></div><div class="cr-disc">−${money(state.discount)}</div></div>`
        : "";
      body.innerHTML = shipBarHTML() + state.cart.map(r => {
        const p = prod(r.id);
        const bg = p.imageUrl ? `style="background-image:url('${p.imageUrl}')"` : "";
        const ph = p.imageUrl ? "" : (emoji[p.category] || "🌿");
        return `<div class="cart-row">
          <div class="cr-img" ${bg}>${ph}</div>
          <div class="cr-info">
            <div class="cr-name">${p.name}</div>
            <div>${money(p.price)}</div>
            <div class="cr-qty">
              <button data-dec="${p.id}">−</button><span>${r.qty}</span><button data-inc="${p.id}">+</button>
            </div>
          </div>
        </div>`;
      }).join("") + discRow;
      $$("#cartItems [data-inc]").forEach(b => b.onclick = () => { addToCart(+b.dataset.inc, 1, { silent: true }); });
      $$("#cartItems [data-dec]").forEach(b => b.onclick = () => decCart(+b.dataset.dec));
    }
    $("#cartTotal").textContent = money(cartTotal());
    updateMobileBar();
  }
  function updateMobileBar() {
    const bar = $("#mobileBar");
    if (!bar) return;
    const has = state.cart.length > 0;
    bar.hidden = !has;
    document.body.classList.toggle("has-bar", has);
    if (has) {
      $("#mbCount").textContent = cartCount();
      $("#mbTotal").textContent = money(cartTotal());
    }
  }
  function shipBarHTML() {
    const th = D.freeShipThreshold, tot = cartTotal();
    if (tot >= th) {
      return `<div class="ship-bar done">${t("shipDone", LANG)}<div class="sb-track"><div class="sb-fill" style="width:100%"></div></div></div>`;
    }
    const pct = Math.min(100, Math.round(tot / th * 100));
    const msg = t("shipRemaining", LANG).replace("{v}", money(th - tot));
    return `<div class="ship-bar">${msg}<div class="sb-track"><div class="sb-fill" style="width:${pct}%"></div></div></div>`;
  }
  function decCart(id) {
    const row = state.cart.find(r => r.id === id);
    if (!row) return;
    row.qty--;
    if (row.qty <= 0) state.cart = state.cart.filter(r => r.id !== id);
    renderCart();
  }
  function openCart() {
    $("#cartDrawer").hidden = false; $("#overlay").hidden = false; renderCart();
    if (state.cart.length && !state.chatOpen) companionSay(comp("cart"));
  }
  function closeCart() { $("#cartDrawer").hidden = true; $("#overlay").hidden = true; }

  /* =========================================================
     5. CHAT — UI
     ========================================================= */
  function openChat() {
    $("#chatPanel").hidden = false;
    $("#chatLauncher").hidden = true;
    state.chatOpen = true; state.minimized = false;
    clearTimeout(minTimer); // annulla il nudge da minimizzato
    clearBadge();
    hideSmokingElf();
    hidePointer();
    startSellerLife();
    if (!$("#chatBody").dataset.started) {
      $("#chatBody").dataset.started = "1";
      startConversation();
    }
    $("#chatInput").focus();
  }
  function minimizeChat() {
    $("#chatPanel").hidden = true;
    $("#chatLauncher").hidden = false;
    state.chatOpen = false; state.minimized = true;
    stopSellerLife();
    showSmokingElf();          // resta nell'angolo a fumare
    scheduleMinimizedNudge();
  }
  function botMsg(text, delay = 600) {
    return new Promise(res => {
      const typing = addTyping();
      setTimeout(() => {
        typing.remove();
        const el = document.createElement("div");
        el.className = "msg bot";
        el.textContent = text;
        $("#chatBody").appendChild(el);
        scrollChat();
        sellerTalk();   // Kaya si muove quando parla
        res();
      }, delay);
    });
  }
  function userMsg(text) {
    const el = document.createElement("div");
    el.className = "msg user";
    el.textContent = text;
    $("#chatBody").appendChild(el);
    scrollChat();
  }
  function addTyping() {
    const el = document.createElement("div");
    el.className = "msg bot typing";
    el.innerHTML = "<i></i><i></i><i></i>";
    $("#chatBody").appendChild(el);
    scrollChat();
    return el;
  }
  function productCard(p, isPick) {
    const el = document.createElement("div");
    el.className = "msg-product" + (isPick ? " kaya-pick" : "");
    if (isPick) el.setAttribute("data-pick", D.seller.pick[LANG] || D.seller.pick.es);
    const bg = p.imageUrl ? `style="background-image:url('${p.imageUrl}')"` : "";
    const ph = p.imageUrl ? "" : (emoji[p.category] || "🌿");
    const rt = prodRating(p);
    el.innerHTML = `<div class="mp-img" ${bg}>${ph}</div>
      <div class="mp-info"><div class="mp-name">${p.name}</div>
      <div class="mp-rating">${starsHTML(rt.stars)}<span class="rev">${rt.stars.toFixed(1)} (${rt.count})</span></div>
      <div class="mp-price">${money(p.price)}</div></div>
      <button class="mp-add">${t("addToCart", LANG)}</button>`;
    el.querySelector(".mp-add").onclick = () => {
      addToCart(p.id);
      const btn = el.querySelector(".mp-add");
      btn.textContent = t("added", LANG);
      setTimeout(() => btn.textContent = t("addToCart", LANG), 1200);
    };
    $("#chatBody").appendChild(el);
    scrollChat();
    return el;
  }
  // posa "che punta" sopra il box durante un consiglio
  let pointerTimer = null;
  function showPointer(target) {
    const panel = $("#chatPanel");
    if (!panel || !state.chatOpen) return;
    panel.classList.add("pointing");                 // nasconde il reclinato
    const pt = $(".chat-pointer");
    if (pt) {                                        // SI METTE IN PIEDI e punta (desktop + mobile)
      pt.hidden = false; void pt.offsetWidth; pt.classList.add("show");
    }
    // PUNTA un prodotto preciso (la scelta di Kaya) e lo esalta come "qualità top"
    $$(".kaya-target").forEach(e => e.classList.remove("kaya-target"));
    const picks = $$(".kaya-pick");
    const pick = target || picks[picks.length - 1];
    if (pick) {
      pick.classList.add("kaya-target");
      // mobile: figura in basso-sx → porta la card in basso per allinearla al braccio
      const blk = window.innerWidth <= 760 ? "end" : "center";
      setTimeout(() => pick.scrollIntoView({ block: blk, behavior: "smooth" }), 150);
    }
    clearTimeout(pointerTimer);
    pointerTimer = setTimeout(hidePointer, 10000);   // resta in piedi a indicare ~10s
  }
  function hidePointer() {
    const panel = $("#chatPanel");
    if (panel) panel.classList.remove("pointing");
    const pt = $(".chat-pointer");
    if (pt) { pt.classList.remove("show"); setTimeout(() => { pt.hidden = true; }, 420); }
    $$(".kaya-target").forEach(e => e.classList.remove("kaya-target"));
  }
  // reazione fisica del venditore (saltello)
  function sellerReact() {
    const s = $(".chat-seller");
    if (!s) return;
    s.classList.remove("react"); void s.offsetWidth; s.classList.add("react");
    setTimeout(() => s.classList.remove("react"), 600);
  }
  // "annuisce"/si muove quando Kaya parla
  function sellerTalk() {
    const s = $(".chat-seller");
    if (!s || !state.chatOpen) return;
    s.classList.remove("talk"); void s.offsetWidth; s.classList.add("talk");
    setTimeout(() => s.classList.remove("talk"), 620);
  }
  // mosse spontanee mentre la chat è aperta (così non è mai fermo)
  let sellerLifeInt = null;
  function startSellerLife() {
    clearInterval(sellerLifeInt);
    sellerLifeInt = setInterval(() => {
      if (!state.chatOpen) return;
      sellerTalk(); // cenno dolce, niente salti bruschi
    }, 7000);
  }
  function stopSellerLife() { clearInterval(sellerLifeInt); }
  let pokeIdx = 0;
  function pokeSeller() {
    sellerReact(); pingSound();
    if (state.chatOpen) { const a = D.seller.poke[LANG]; botMsg(a[pokeIdx++ % a.length], 400); }
  }
  // CROSS-SELL concatenato: "ya que llevas X, llévate Y que te hará falta"
  let chainIdx = 0;
  function crossSell(p) {
    if (!p) return;
    const upCat = D.upsell[p.category];
    if (!upCat) return;
    const comp = D.products.find(x => x.category === upCat && x.id !== p.id && !state.cart.find(c => c.id === x.id));
    if (!comp) return;
    const arr = D.seller.chain[LANG];
    const line = arr[chainIdx++ % arr.length].replace("{x}", p.name).replace("{y}", comp.name);
    if (state.chatOpen) {
      botMsg(line, 700).then(() => { productCard(comp, true); showPointer(); });
    } else {
      companionSay(line.replace(" 👇", ""), 6500);
    }
  }
  function quickReplies(options) {
    const q = $("#chatQuick");
    q.innerHTML = "";
    options.forEach(opt => {
      const b = document.createElement("button");
      b.textContent = opt.label;
      b.onclick = () => { clearQuick(); opt.onClick(); };
      q.appendChild(b);
    });
    // le quick-reply restringono la chat: ri-scrolla così l'ultimo messaggio resta visibile
    requestAnimationFrame(() => requestAnimationFrame(scrollChat));
  }
  function clearQuick() { $("#chatQuick").innerHTML = ""; }
  let stickBottom = true;
  function scrollChat() {
    const b = $("#chatBody"); if (!b) return;
    if (!b._scrollBound) {
      b._scrollBound = true;
      b.addEventListener("scroll", () => {
        stickBottom = (b.scrollHeight - b.scrollTop - b.clientHeight) < 90;
      }, { passive: true });
    }
    // auto-scroll solo se l'utente è già in fondo: se sta leggendo sopra, non lo strappiamo
    if (stickBottom) b.scrollTo({ top: b.scrollHeight, behavior: "smooth" });
  }

  /* =========================================================
     6. CHAT — MOTORE BUDTENDER (profilazione + neuromarketing)
     ========================================================= */
  async function startConversation() {
    state.engaged = true;
    await botMsg(D.greetings[LANG], 500);
    askProfilingStep();
  }

  function setProfProgress(step, total) {
    const p = $("#chatProg");
    if (step >= total) { p.hidden = true; return; }
    p.hidden = false;
    $("#chatProgLabel").textContent = t("profStep", LANG).replace("{a}", step + 1).replace("{b}", total);
    $("#chatProgFill").style.width = Math.round(step / total * 100) + "%";
  }
  // re-render quick replies + progress della domanda corrente (usato anche al cambio lingua)
  function renderProfilingQuick(q) {
    setProfProgress(state.step, D.profiling.length);
    quickReplies(q.options.map(o => ({
      label: o[LANG],
      onClick: () => {
        userMsg(o[LANG]);
        state.profile[q.intent] = o.val;
        state.step++;
        askProfilingStep();
      }
    })));
  }
  function askProfilingStep() {
    state.flow = "profiling";
    const q = D.profiling[state.step];
    if (!q) { recommend(); return; }
    botMsg(q.q[LANG], 500).then(() => renderProfilingQuick(q));
  }

  // Dopo la profilazione: filtra prodotti e vende con tattica
  async function recommend() {
    state.flow = "recommend";
    clearQuick();
    $("#chatProg").hidden = true;
    const cat = state.profile.category;
    const budget = state.profile.budget;
    let pool = D.products.slice();
    if (cat && cat !== "any") pool = pool.filter(p => p.category === cat);
    if (budget === "low") pool = pool.filter(p => p.price < 15);
    else if (budget === "mid") pool = pool.filter(p => p.price >= 15 && p.price <= 50);
    else if (budget === "high") pool = pool.filter(p => p.price > 50);
    let budgetMissed = false;
    if (!pool.length) {
      budgetMissed = !!budget && budget !== "any";
      pool = cat && cat !== "any" ? D.products.filter(p => p.category === cat) : D.products.slice();
    }
    // ordina: badge prima, poi prezzo crescente
    pool.sort((a, b) => ((b.badge ? 1 : 0) - (a.badge ? 1 : 0)) || (a.price - b.price));
    const picks = pool.slice(0, 2);

    // 1) un solo messaggio di apertura + i prodotti (il 1° è "la scelta di Kaya")
    const lead = budgetMissed
      ? { es: "En ese presupuesto justo no tengo nada aquí, pero esto es lo más cercano 👇", en: "Nothing in that exact budget here, but this is the closest 👇", it: "In quel budget preciso non ho nulla qui, ma ecco il più vicino 👇" }[LANG]
      : { es: "¡Genial! Con lo que me cuentas, esto va contigo 👇", en: "Awesome! Based on what you told me, these are for you 👇", it: "Perfetto! Da quello che mi dici, questi fanno per te 👇" }[LANG];
    // UN solo messaggio + i prodotti (il 1° è la scelta di Kaya)
    await botMsg(lead, 700);
    let heroCard = null;
    picks.forEach((p, i) => { const c = productCard(p, i === 0); if (i === 0) heroCard = c; });

    // Kaya si alza e PUNTA il suo top, esaltandone la qualità (non a caso)
    const hero = picks[0];
    if (hero) {
      const r = prodRating(hero);
      const qline = {
        es: `👉 Mi favorito es el ${hero.name}: ${r.stars.toFixed(1)}★ (${r.count} reseñas). Calidad de verdad — es el que yo me llevaría.`,
        en: `👉 My favourite is the ${hero.name}: ${r.stars.toFixed(1)}★ (${r.count} reviews). Real quality — it's the one I'd take myself.`,
        it: `👉 Il mio preferito è il ${hero.name}: ${r.stars.toFixed(1)}★ (${r.count} recensioni). Qualità vera — è quello che prenderei io.`
      }[LANG];
      await botMsg(qline, 900);
    }
    showPointer(heroCard);

    // il pack come UNICA aggiunta (la mossa di vendita), dopo una pausa
    const bundle = picks.slice();
    const up = picks[0] && D.upsell[picks[0].category];
    const upProd = up && D.products.find(p => p.category === up && !bundle.includes(p));
    if (upProd) bundle.push(upProd);
    state.flow = "free";
    if (bundle.length >= 2) await offerBundle(bundle);
    offerFreeQuick();   // le quick-reply fanno da chiusura, niente messaggio extra
  }

  // offerta pacchetto: anchoring sul totale + sconto pack 15%
  async function offerBundle(items) {
    const was = items.reduce((s, p) => s + p.price, 0);
    const now = Math.round(was * 0.85 * 100) / 100;
    const save = Math.round((was - now) * 100) / 100;
    const msg = D.seller.bundle[LANG]
      .replace("{was}", money(was)).replace("{now}", money(now)).replace("{save}", money(save));
    await botMsg(msg, 1300);
    // CTA persistente nel corpo chat (non una quick-reply che verrebbe sovrascritta)
    const el = document.createElement("div");
    el.className = "msg-product bundle-cta";
    el.innerHTML = `<div class="mp-img">🎁</div>
      <div class="mp-info"><div class="mp-name">Pack ×${items.length}</div>
      <div class="mp-price">${money(now)} <span class="price-was">${money(was)}</span></div></div>
      <button class="mp-add">${D.seller.bundleAdd[LANG].replace("{save}", money(save))}</button>`;
    const btn = el.querySelector(".mp-add");
    btn.onclick = () => {
      if (btn.disabled) return;
      items.forEach(p => addToCart(p.id, 1, { silent: true }));
      state.discount += save;          // applica DAVVERO lo sconto pack al carrello
      renderCart();
      toast(t("added", LANG)); pingSound(); cartBump();
      btn.textContent = t("added", LANG); btn.disabled = true;
      botMsg(D.seller.assumptiveClose[LANG], 500);
    };
    $("#chatBody").appendChild(el);
    scrollChat();
  }

  // richiesta valutazione a stelle dopo il checkout (boost rating + reciprocità con codice)
  async function askRating() {
    await botMsg(D.marketing.ratePrompt[LANG], 700);
    const el = document.createElement("div");
    el.className = "rate-stars";
    for (let i = 1; i <= 5; i++) {
      const b = document.createElement("button");
      b.textContent = "★"; b.setAttribute("aria-label", i + " estrellas");
      b.onmouseover = () => [...el.children].forEach((c, idx) => c.classList.toggle("hot", idx < i));
      b.onclick = () => {
        [...el.children].forEach((c, idx) => { c.classList.toggle("hot", idx < i); c.disabled = true; });
        pingSound();
        botMsg(D.marketing.rateThanks[LANG].replace("{n}", i), 500);
      };
      el.appendChild(b);
    }
    $("#chatBody").appendChild(el);
    scrollChat();
  }
  function pickTactic(profile, picks) {
    if (profile.experience === "beginner") return D.tactics.authority[LANG];
    if (profile.experience === "expert") return D.tactics.socialProof[LANG];
    if (profile.category === "CBD" || profile.experience === "cbd") return D.tactics.sensory[LANG];
    if (profile.budget === "high") return D.tactics.anchoring[LANG];
    if (profile.category === "Accendini") return D.tactics.lossAversion[LANG];
    return D.tactics.socialProof[LANG];
  }

  function offerFreeQuick() {
    const opts = [
      { es: "Ver más opciones", en: "See more options", it: "Vedi altre opzioni" },
      { es: "¿Es legal el CBD?", en: "Is CBD legal?", it: "Il CBD è legale?" },
      { es: "Envío y entrega", en: "Shipping & delivery", it: "Spedizione e consegna" }
    ];
    quickReplies(opts.map(o => ({
      label: o[LANG], onClick: () => handleUser(o[LANG])
    })));
  }

  // Input libero → obiezioni, keyword categoria, fallback
  async function handleUser(text) {
    userMsg(text);
    clearQuick();
    state.engaged = true;

    if (CFG.useClaude && CFG.apiKey) { await claudeReply(text); return; }

    const low = text.toLowerCase();

    // 1) obiezioni
    for (const obj of D.objections) {
      if (obj.keys[LANG].some(k => low.includes(k))) {
        await botMsg(obj.r[LANG], 700);
        offerFreeQuick();
        return;
      }
    }
    // 2) categoria per keyword
    const catMap = {
      Cartine: ["cartina", "papel", "paper", "rolling", "raw", "liar", "rollare"],
      Grinder: ["grinder", "moler", "macina", "tritar"],
      Accendini: ["mechero", "lighter", "clipper", "accendino", "encendedor", "fuego"],
      Vaporizzatori: ["vape", "vaper", "vapor", "vaporizz"],
      CBD: ["cbd", "aceite", "olio", "oil", "rosin", "hash", "bienestar", "relax", "benessere"],
      Edibles: ["dulce", "sweet", "dolce", "lolli", "té", "te ", "tea", "comestible", "edible"],
      Accessori: ["cenicero", "ashtray", "posacenere", "accesorio", "accessory", "accessori", "kit"]
    };
    for (const [cat, keys] of Object.entries(catMap)) {
      if (keys.some(k => low.includes(k))) {
        const list = D.products.filter(p => p.category === cat).slice(0, 2);
        const cl = catLabel(cat);
        await botMsg({
          es: `¡Buena elección! Mira lo que tengo en ${cl} 👇`,
          en: `Great choice! Here's what I have in ${cl} 👇`,
          it: `Ottima scelta! Ecco cosa ho in ${cl} 👇`
        }[LANG], 700);
        list.forEach(p => productCard(p));
        await botMsg(pickTactic({ category: cat }, list), 800);
        offerFreeQuick();
        return;
      }
    }
    // 3) "ver más / more"
    if (/(más|mas|more|altro|otras|other)/.test(low)) {
      const picks = D.products.filter(p => p.badge).slice(0, 3);
      await botMsg({ es: "Estos son los favoritos de la casa 👇", en: "These are the house favorites 👇", it: "Questi sono i preferiti della casa 👇" }[LANG], 600);
      picks.forEach(p => productCard(p));
      offerFreeQuick();
      return;
    }
    // 4) fallback empatico + reindirizza
    await botMsg({
      es: "Te leo. Dime: ¿lo quieres para liar, vapear, relajarte con CBD o algo dulce? Así te clavo la recomendación. 🌿",
      en: "Got you. Tell me: rolling, vaping, CBD relaxation or something sweet? Then I'll nail the pick. 🌿",
      it: "Ti seguo. Dimmi: per rollare, vaporizzare, rilassarti col CBD o qualcosa di dolce? Così azzecco il consiglio. 🌿"
    }[LANG], 700);
    offerFreeQuick();
  }

  /* =========================================================
     7. CLAUDE API (opzionale) — attivo solo con chiave
     ========================================================= */
  function systemPrompt() {
    const cat = D.products.map(p => `- ${p.name} | ${p.category} | ${money(p.price)} | ${p.description}`).join("\n");
    return `Sei "Kaya", budtender di Kayaman's Farm (smoke shop & CBD boutique, Las Palmas, solo +18).
Parla in ${LANG === "es" ? "spagnolo" : LANG === "en" ? "inglese" : "italiano"}. Tono: chill, esperto, amichevole, mai invadente.
Profila il cliente, consiglia per stile di vita e budget, fai cross-sell con tatto. Niente promesse mediche. Sempre +18.
Usa tecniche di neuromarketing (riprova sociale, scarsità, autorità) con misura.
CATALOGO:\n${cat}`;
  }
  let history = [];
  async function claudeReply(text) {
    history.push({ role: "user", content: text });
    const typing = addTyping();
    try {
      const res = await fetch("https://api.anthropic.com/v1/messages", {
        method: "POST",
        headers: {
          "content-type": "application/json",
          "x-api-key": CFG.apiKey,
          "anthropic-version": "2023-06-01",
          "anthropic-dangerous-direct-browser-access": "true"
        },
        body: JSON.stringify({
          model: CFG.model, max_tokens: 400,
          system: systemPrompt(), messages: history
        })
      });
      const data = await res.json();
      typing.remove();
      const reply = (data.content && data.content[0] && data.content[0].text) || "…";
      history.push({ role: "assistant", content: reply });
      const el = document.createElement("div");
      el.className = "msg bot"; el.textContent = reply;
      $("#chatBody").appendChild(el); scrollChat();
    } catch (e) {
      typing.remove();
      await botMsg("⚠️ " + ({ es: "No pude conectar con la IA, sigo en modo budtender experto.", en: "Couldn't reach the AI, staying in expert budtender mode.", it: "Non riesco a contattare l'IA, resto in modalità budtender esperto." }[LANG]), 200);
      CFG.useClaude = false;
      handleUser(text);
    }
  }

  /* =========================================================
     8. RE-ENGAGEMENT "SPIETATO"
     ========================================================= */
  let idleTimer = null, minTimer = null, idleCount = 0, exitShown = false, titleFlash = null;
  const baseTitle = document.title;

  function startReengage() {
    ["mousemove", "keydown", "click", "scroll", "touchstart"].forEach(ev =>
      document.addEventListener(ev, resetIdle, { passive: true }));
    resetIdle();
    // exit-intent solo su desktop con mouse (su touch non ha senso e non si attiva)
    const isTouch = window.matchMedia && window.matchMedia("(pointer:coarse)").matches;
    if (CFG.exitIntentEnabled && !isTouch) document.addEventListener("mouseout", onExitIntent);
    document.addEventListener("visibilitychange", onVisibility);
  }
  function scheduleIdle() {
    clearTimeout(idleTimer);
    idleTimer = setTimeout(onIdle, CFG.idleSeconds * 1000);
  }
  function resetIdle() {
    // l'elfo NON sparisce col movimento del mouse: resta nell'angolo finché la chat è chiusa.
    // si nasconde solo aprendo la chat (openChat). Qui riavvio solo il timer dei nudge.
    scheduleIdle();
  }
  function onIdle() {
    // cap: max 3 nudge totali, per non essere fastidiosi (specie la vibrazione su mobile)
    if (idleCount >= 3) return;
    const idx = idleCount % D.reengage.idle.es.length;
    idleCount++;
    if (state.chatOpen) {
      botMsg(D.reengage.idle[LANG][idx], 300);
    } else {
      showSmokingElf();
      companionSay(D.reengage.idle[LANG][idx]);  // commento nel fumetto, lingua corrente
      vibrate([60]);
    }
    if (idleCount < 3) scheduleIdle();
  }
  let elfHideTimer = null;
  function showSmokingElf() {
    const e = $("#elfSmoke");
    if (!e || state.chatOpen) return;
    clearTimeout(elfHideTimer);  // annulla un eventuale fade-out in corso
    e.hidden = false;
    e.classList.add("show");
    // stile inline pilotato via rAF: garantisce l'entrata animata
    requestAnimationFrame(() => requestAnimationFrame(() => {
      e.style.opacity = "1";
      e.style.transform = "translateY(0) rotate(0)";
    }));
  }
  function hideSmokingElf() {
    const e = $("#elfSmoke");
    hideBubble();
    if (!e || e.hidden) return;
    e.style.opacity = "0";
    e.style.transform = "translateY(40px) rotate(6deg)";
    e.classList.remove("show");
    clearTimeout(elfHideTimer);
    elfHideTimer = setTimeout(() => { if (e.style.opacity === "0") e.hidden = true; }, 500);
  }
  // ===== ELFO COMPAGNO: fumetti contestuali =====
  let bubbleTimer = null, addReactIdx = 0;
  function comp(key) { const c = D.companion[key]; return c ? (c[LANG] || c.es) : ""; }
  function companionSay(text, ms = 5500) {
    if (state.chatOpen || !text) return;
    showSmokingElf();                 // l'elfo è presente quando parla
    const b = $("#elfBubble");
    if (!b) return;
    b.textContent = text;
    b.hidden = false;
    requestAnimationFrame(() => requestAnimationFrame(() => b.classList.add("show")));
    clearTimeout(bubbleTimer);
    bubbleTimer = setTimeout(hideBubble, ms);
  }
  function hideBubble() {
    const b = $("#elfBubble");
    if (!b || b.hidden) return;
    b.classList.remove("show");
    clearTimeout(bubbleTimer);
    bubbleTimer = setTimeout(() => { b.hidden = true; }, 300);
  }
  // reazione + STRATEGIA all'aggiunta al carrello (guida la spesa e concatena)
  function onAdded(p) {
    if (state.chatOpen) { crossSell(p); return; }   // in chat: catena di prodotti
    const rem = D.freeShipThreshold - cartTotal();
    if (rem <= 0) companionSay(comp("shipDone"));
    else if (rem <= 25) companionSay(D.companion.shipClose[LANG].replace("{v}", money(rem)));
    else crossSell(p);   // bolla: "ya que llevas X, llévate Y"
  }
  let pendingIdleIdx = null;

  function scheduleMinimizedNudge() {
    clearTimeout(minTimer);
    minTimer = setTimeout(() => {
      if (state.minimized && !state.chatOpen) {
        bumpBadge();
        nudgeLauncher();
        vibrate([120, 60, 120]);
        pingSound();
        flashTitle(D.reengage.tabBait[LANG]);
      }
    }, CFG.minimizedNudgeSeconds * 1000);
  }

  function bumpBadge() {
    state.badge++;
    const b = $("#chatBadge");
    b.hidden = false; b.textContent = state.badge;
    nudgeLauncher();
    vibrate([90]);
    pingSound();
  }
  function clearBadge() {
    state.badge = 0;
    $("#chatBadge").hidden = true;
    // se c'era un nudge idle in sospeso, Kaya lo dice all'apertura NELLA LINGUA ATTUALE
    if (pendingIdleIdx != null) {
      const arr = D.reengage.idle[LANG], m = arr[pendingIdleIdx % arr.length];
      pendingIdleIdx = null;
      setTimeout(() => botMsg(m, 300), 400);
    }
  }
  function nudgeLauncher() {
    const l = $("#chatLauncher");
    if (l.hidden) return;
    l.classList.remove("nudge"); void l.offsetWidth; l.classList.add("nudge");
  }

  // vibrazione (mobile) + beep (desktop)
  function vibrate(pattern) {
    if (CFG.vibrate && navigator.vibrate) { try { navigator.vibrate(pattern); } catch (e) {} }
  }
  let audioCtx = null;
  function pingSound() {
    if (!CFG.sound) return;
    try {
      audioCtx = audioCtx || new (window.AudioContext || window.webkitAudioContext)();
      const o = audioCtx.createOscillator(), g = audioCtx.createGain();
      o.connect(g); g.connect(audioCtx.destination);
      o.type = "sine"; o.frequency.value = 880;
      g.gain.setValueAtTime(0.0001, audioCtx.currentTime);
      g.gain.exponentialRampToValueAtTime(0.12, audioCtx.currentTime + 0.02);
      g.gain.exponentialRampToValueAtTime(0.0001, audioCtx.currentTime + 0.25);
      o.start(); o.stop(audioCtx.currentTime + 0.26);
    } catch (e) {}
  }

  // exit-intent: il mouse esce dall'alto della pagina
  function onExitIntent(e) {
    if (exitShown) return;
    if (window.matchMedia && matchMedia("(pointer:coarse)").matches) return; // mai su touch
    if (document.getElementById("exitPopup") && !document.getElementById("exitPopup").hidden) return;
    // solo quando il cursore esce davvero dalla cima della finestra
    if (e.clientY > 0) return;
    if (e.relatedTarget && e.relatedTarget.nodeName !== "HTML") return;
    exitShown = true;
    document.removeEventListener("mouseout", onExitIntent); // one-shot: non serve più
    showExitPopup();
  }
  let exitInt = null;
  function stopExitCountdown() { clearInterval(exitInt); exitInt = null; }
  function showExitPopup() {
    $("#exitPopup").hidden = false;
    vibrate([150, 80, 150]); pingSound();
    let secs = 300;
    const cd = $("#exitCountdown");
    const tick = () => {
      const m = String(Math.floor(secs / 60)).padStart(2, "0");
      const s = String(secs % 60).padStart(2, "0");
      cd.textContent = `${m}:${s}`;
      if (secs-- <= 0) stopExitCountdown();
    };
    tick();
    stopExitCountdown();
    exitInt = setInterval(tick, 1000);
  }

  // cambio scheda: titolo lampeggia per "riportare" l'utente
  function onVisibility() {
    if (document.hidden) {
      const bait = D.reengage.tabBait[LANG];
      flashTitle(bait);
    } else {
      stopFlashTitle();
      if (state.minimized || !state.chatOpen) { /* lascia il badge */ }
    }
  }
  function flashTitle(text) {
    stopFlashTitle();
    let on = false;
    titleFlash = setInterval(() => {
      document.title = on ? baseTitle : text;
      on = !on;
    }, 1000);
  }
  function stopFlashTitle() {
    clearInterval(titleFlash); titleFlash = null; document.title = baseTitle;
  }

  /* =========================================================
     9. TOAST
     ========================================================= */
  let toastTimer = null;
  function toast(msg) {
    let el = $(".toast");
    if (!el) { el = document.createElement("div"); el.className = "toast"; document.body.appendChild(el); }
    el.textContent = msg;
    el.style.display = "block";
    clearTimeout(toastTimer);
    toastTimer = setTimeout(() => el.style.display = "none", 1400);
  }

  /* =========================================================
     9b. SOCIAL PROOF (bilanciato)
     ========================================================= */
  let spIdx = 0;
  function socialToast() {
    if (document.hidden || state.chatOpen) return;
    if (spIdx >= 5) { clearInterval(socialInt); return; } // max 5 volte, niente spam
    const list = D.socialProof[LANG];
    const n = 5 + Math.floor(Math.random() * 14);
    const m = 2 + Math.floor(Math.random() * 12);
    const html = list[spIdx % list.length].replace("{n}", n).replace("{m}", m);
    spIdx++;
    let el = $(".toast.sp");
    if (!el) { el = document.createElement("div"); el.className = "toast sp"; document.body.appendChild(el); }
    el.innerHTML = html;
    el.style.display = "block";
    clearTimeout(el._t);
    el._t = setTimeout(() => el.style.display = "none", 4200);
  }
  let socialInt = null;
  function startSocialProof() {
    setTimeout(socialToast, 14000);
    clearInterval(socialInt);
    socialInt = setInterval(socialToast, 42000); // ~ogni 42s, max 5 volte
  }

  /* =========================================================
     10. WIRING
     ========================================================= */
  function init() {
    LANG = detectLang();
    setLang(LANG);
    initAgeGate();
    window.addEventListener("scroll", onScrollLazy, { passive: true });
    window.addEventListener("resize", checkLazy);

    $$(".lang-switch button").forEach(b => b.onclick = () => setLang(b.dataset.lang));
    $("#cartBtn").onclick = openCart;
    $("#cartClose").onclick = closeCart;
    $("#overlay").onclick = closeCart;
    $("#checkoutBtn").onclick = () => {
      if (!state.cart.length) { toast(t("emptyCart", LANG)); return; }
      const msg = t("checkoutMsg", LANG).replace("{t}", money(cartTotal()));
      $("#chatBody").dataset.started = "1"; // contesto post-acquisto: niente intro vendite
      state.flow = "free";
      closeCart(); openChat();
      botMsg(msg, 300).then(askRating);   // dopo l'acquisto chiede la valutazione ⭐
      state.cart = []; renderCart();
    };
    $("#heroCta").onclick = () => scrollToShop();
    $("#heroCta2").onclick = openChat;
    $("#hamburger").onclick = () => document.querySelector(".navbar").classList.toggle("open");
    $("#promoClose").onclick = () => { $("#promoBar").style.display = "none"; if (promoInt) clearInterval(promoInt); };
    $("#chatLauncher").onclick = openChat;
    $("#elfSmoke").onclick = openChat;   // toccare l'elfo apre la chat
    $("#elfBubble").onclick = openChat;  // toccare il fumetto apre la chat
    const sellerEl = $(".chat-seller"); if (sellerEl) sellerEl.onclick = pokeSeller; // stuzzica il venditore
    const heroM = $(".hero-mascot"); if (heroM) { heroM.style.cursor = "pointer"; heroM.onclick = openChat; }
    // ricerca: filtra la griglia per nome/categoria
    $("#searchForm").onsubmit = e => { e.preventDefault(); doSearch($("#searchInput").value.trim()); };
    // account / login: demo → apre Kaya
    ["#hrAccount", "#tbLogin", "#tbRegister"].forEach(sel => { const el = $(sel); if (el) el.onclick = e => { e.preventDefault(); openChat(); }; });
    // barra sticky mobile → apre il carrello
    $("#mbCta").onclick = openCart;
    $("#mobileBar").onclick = e => { if (e.target.id !== "mbCta") openCart(); };
    // newsletter: cattura email → codice sconto
    $("#nlForm").onsubmit = e => {
      e.preventDefault();
      const email = $("#nlEmail").value.trim();
      if (!email) return;
      $("#nlForm").hidden = true;
      const th = $("#nlThanks");
      th.textContent = D.marketing.newsletter.thanks[LANG] || D.marketing.newsletter.thanks.es;
      th.hidden = false;
      pingSound();
    };
    $("#chatMin").onclick = minimizeChat;
    $("#chatForm").onsubmit = e => {
      e.preventDefault();
      const v = $("#chatInput").value.trim();
      if (!v) return;
      $("#chatInput").value = "";
      handleUser(v);
    };
    // exit popup
    const closeExit = () => { $("#exitPopup").hidden = true; stopExitCountdown(); };
    $("#exitClose").onclick = closeExit;
    $("#exitPopup").onclick = e => { if (e.target.id === "exitPopup") closeExit(); }; // tocca lo sfondo per chiudere
    $("#exitCta").onclick = () => {
      $("#exitPopup").hidden = true; stopExitCountdown();
      openChat();
      setTimeout(() => botMsg({ es: "¡Código KAYA10 activado! 🎉 Te aplico el 10%. ¿Empezamos por algo para liar o CBD?", en: "Code KAYA10 activated! 🎉 10% is on. Shall we start with rolling gear or CBD?", it: "Codice KAYA10 attivato! 🎉 Applico il 10%. Partiamo da qualcosa per rollare o dal CBD?" }[LANG], 400), 300);
    };
  }

  if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", init);
  else init();
})();
